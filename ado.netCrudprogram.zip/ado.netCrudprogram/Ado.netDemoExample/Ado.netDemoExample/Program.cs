﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Ado.netDemoExample
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
                //Sql Connection
                SqlConnection con = new SqlConnection(constring);
                con.Open();
                Console.WriteLine("Select any operation to perform: ");
                Console.WriteLine("1) Create 2) Select 3) Update 4)select by id ");
                string CRUD = Console.ReadLine();
                switch (CRUD)
                {
                    case "1":
                        Console.Write("Enter Employee Id : ");
                        int empid = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Employee Name : ");
                        string empname = Console.ReadLine();
                        Console.Write("Enter Employee Salary : ");
                        int empsalary = Convert.ToInt32(Console.ReadLine());
                        string insertquery = String.Format("insert into Employee values({0},'{1}',{2})", empid, empname, empsalary);
                        SqlCommand insertcmd = new SqlCommand(insertquery, con);
                        int rowsAdded = insertcmd.ExecuteNonQuery();
                        Console.WriteLine(rowsAdded + "Row Effected");
                        break;
                    case "2": //displaying the output
                        string selectquery = "select * from Employee";
                        SqlCommand selectcmd = new SqlCommand(selectquery, con);
                        SqlDataReader dr2 = selectcmd.ExecuteReader();
                        while (dr2.Read())
                        {
                            //Inserted column Names as dr[columnname]
                            int id = Convert.ToInt32(dr2["id"]);
                            string Name = Convert.ToString(dr2["EmpName"]);
                            int Salary = Convert.ToInt32(dr2["EmpSalary"]);
                            Console.WriteLine(id + " " + Name + " " + Salary);
                        }
                        break;
                    case "3":
                        Console.Write("Enter Employee Id : ");
                        int eid = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Employee Salary : ");
                        int esalary = Convert.ToInt32(Console.ReadLine());
                        string updatequery = "update Employee set EmpSalary =" + esalary + "where Empid=" + eid;
                        SqlCommand updatecmd = new SqlCommand(updatequery, con);
                        int updatecreated = updatecmd.ExecuteNonQuery();
                        break;                    
                    case "4":
                        Console.Write("Enter Employee id :");
                        int emp_id = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter Employee Name :");
                        string emp_name = Console.ReadLine();
                        Console.Write("Enter Employee Salary");
                        int emp_salary = Convert.ToInt32(Console.ReadLine());
                        String pname = "datainsert";
                        SqlCommand com = new SqlCommand(pname, con);
                        com.CommandType = System.Data.CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("@id", emp_id);
                        com.Parameters.AddWithValue("@empname", emp_name);
                        com.Parameters.AddWithValue("@empsalary", emp_salary);                       
                        com.ExecuteNonQuery();
                        break;
                }
                
                Console.ReadKey();

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
