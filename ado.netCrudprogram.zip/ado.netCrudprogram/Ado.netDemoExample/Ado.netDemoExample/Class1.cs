﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Ado.netDemoExample
{
    class Class1
    {
        public static void Main(string[] args)
        {
            try
            {
                //Conncection String  from App.config
                string constring = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;

                //Sql Connection Connection
                SqlConnection con = new SqlConnection(constring);

                //Queries to perform operations like select insert update and delete 
                string query = "select * from Employee";
                string query1 = "insert into Employee values(6,'Manasa',2000),(7,'Umesh babu',23000)";
                string query2 = "update Employee set Empname='Asiya' where id=6";
                string query3 = "delete from Employee where id=6";

                //Sqlcommand obj to perform queries  
                SqlCommand cmd = new SqlCommand(query, con);
                SqlCommand cmd1 = new SqlCommand(query1, con);
                SqlCommand cmd2 = new SqlCommand(query2, con);
                SqlCommand cmd3 = new SqlCommand(query3, con);


                //Now open sqlConnection 
                con.Open();

                //Return type is integer and use ExecuteNonQuery Command to perform operations
                int rowsAdded = cmd1.ExecuteNonQuery();
                int rowsupdated = cmd2.ExecuteNonQuery();
                //Console.WriteLine("Effected rows are " + rowsAdded);
                int deleteperformed = cmd3.ExecuteNonQuery();



                //Returntype is Datareader 
                SqlDataReader dr = cmd.ExecuteReader();

                //Use while to retrieve the data using object of sqldatareader
                while (dr.Read())
                {
                    //Inserted column Names as dr[columnname]
                    int id = Convert.ToInt32(dr["id"]);
                    string Name = Convert.ToString(dr["EmpName"]);
                    int Salary = Convert.ToInt32(dr["EmpSalary"]);
                    Console.WriteLine(id + " " + Name + " " + Salary);
                }

            }
            catch (SqlException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
