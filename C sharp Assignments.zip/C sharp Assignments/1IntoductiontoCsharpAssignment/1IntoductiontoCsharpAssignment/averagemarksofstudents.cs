﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1IntoductiontoCsharpAssignment
{
    class averagemarksofstudents
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Average marks of student1:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Average marks of student2:");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Average marks of student3:");
            int c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Average marks of student4:");
            int d = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Average marks of student5:");
            var e = Convert.ToInt32(Console.ReadLine());
            int[] array1 = new int[10];
            array1[0] = a;
            array1[1] = b;
            array1[2] = c;
            array1[3] = d;
            array1[4] = e;

            /* var list = new List<int>();
             list.Add(a);
             list.Add(b);
             list.Add(b);
             list.Add(c);
             list.Add(d);
             list.Add(e);

             // Iterate list element using foreach loop  
             foreach (var i in list)
             {
                 Console.Write(i + " ");
             } */

            Console.WriteLine("the highest marks obtained is :" + array1.Max());
            Console.ReadLine();

        }
    }
}
