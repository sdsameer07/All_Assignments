﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1IntoductiontoCsharpAssignment
{
    class calculator
    {
        static void Main(string[] args)
        {
            //Reading inputs from the user

            Console.WriteLine("Enter the a value : ");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the b value : ");
            int b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter any opration: + - * /");
            string c = Console.ReadLine();

            //logic using switch case

            switch (c)
            {
                case "+":
                    //displaying the output
                    Console.WriteLine("Addition of two numbers is " + (a + b));
                    break;
                case "-":
                    Console.WriteLine("Subtraction of two numbers is " + (a - b));
                    break;
                case "*":
                    Console.WriteLine("Multiplication of two numbers is " + (a * b));
                    break;
                case "/":
                    Console.WriteLine("Division of two numbers is " + (a / b));
                    break;
            }
            Console.ReadKey();
            

        }
    }

    }
