﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1IntoductiontoCsharpAssignment
{
    class Areacircumferenceofarea
    {
       static void Mymethod()
        {

            double pi = 3.14;
            Console.WriteLine("Enter the radius value : ");
            int radius = Convert.ToInt32(Console.ReadLine());
            double area;
            area = pi * radius * radius;
            Console.WriteLine("Area of a circle is :" + area);
            double area1;
            area1 = 2 * pi * radius;
            Console.WriteLine("Circumference of a circle is :" + area1); 

        } 
        static void Main()
        {
            Mymethod();
            Console.ReadKey();
        }
    }
}
