﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1IntoductiontoCsharpAssignment
{
    class Swapping2numbers
    {
        static void Mymethod()
        {
            int temp;
            Console.WriteLine("Enter a value");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter b value");
            int b = Convert.ToInt32(Console.ReadLine());
            temp = a;
            a = b;
            b = temp;
            Console.WriteLine("After swapping a = " + a +" b = " + b);
        }
        static  void Main(string[] args)
        {
            Mymethod();
            Console.ReadKey();
        }
    }
}
