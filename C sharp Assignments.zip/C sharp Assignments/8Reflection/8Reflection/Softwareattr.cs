﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;


namespace _8Reflection
{

   [AttributeUsageAttribute( AttributeTargets.All )]
 class SoftwareAtttribute : Attribute
    {
        private string Projectname;
        private string description;
        private string Clientname;
        private string Starteddate;
        private string Enddate;
        private string v1;
        private string v2;

        public SoftwareAtttribute(string Projectname, string description, string Clientname, string Starteddate, string Enddate)
        {
            this.Projectname = Projectname;
            this.description = description;
            this.Clientname = Clientname;
            this.Starteddate = Starteddate;
            this.Enddate = Enddate;
        }
        public string ProjectName
        {
            get { return Projectname; }
        }
        public string Description
        {
            get { return description; }
        }
        public string ClientName
        {
            get { return Clientname; }
        }
        public string Startedate
        {
            get { return Starteddate; }
        }
        public string EndDate
        {
            get { return Enddate; }
        }

        public SoftwareAtttribute(string v1, string v2)
        {
            this.v1 = v1;
            this.v2 = v2;
        }
        public static void SoftwareAttributeDisplay(Type classType)
        {
            Console.WriteLine("Methods of class {0}", classType.Name);
            Assembly executing = Assembly.GetExecutingAssembly();
            Type[] types = executing.GetTypes();

            foreach (var item in types)
            {
                Console.WriteLine("Class : {0}", item.Name);
                MethodInfo[] methods = item.GetMethods();
                foreach (var method in methods)
                {
                    Console.WriteLine("--> Method : {0}", method.Name);

                    ParameterInfo[] parameters = method.GetParameters();
                    foreach (var arg in parameters)
                    {
                        Console.WriteLine("----> Parameter : {0} Type : {1}",
                                                arg.Name, arg.ParameterType);
                    }
                }
            }
        }
    }

    class HDFCAccount
    {
        private int Accountnumber;
        private string AccountholderName;
        private double Balance;
        public void displayAccountdetails(int Accountnumber, string AccountholderName, double Balance)
        {

            this.Accountnumber = Accountnumber;
            this.AccountholderName = AccountholderName;
            this.Balance = Balance;

        }

        [SoftwareAtttribute("Accessor", "Returns Value of getAccountNumber")]
        public int getAccountNumber()
        {
            return Accountnumber;
        }

        [SoftwareAtttribute("Accessor", "Returns Value of accountholderName")]
        public string accountholderName()
        {
            return AccountholderName;
        }

        [SoftwareAtttribute("Accessor", "Returns Value of Balance")]
        public double balance()
        {
            return Balance;
        }

        class ICICIAccount
        {
            private int Accountnumber;
            private string AccountholderName;
            private double Balance;
            private int pincode;
            public void displayAccountdetails(int Accountnumber, string AccountholderName, double Balance, int pincode)
            {

                this.Accountnumber = Accountnumber;
                this.AccountholderName = AccountholderName;
                this.Balance = Balance;
                this.pincode = pincode;

            }

            [SoftwareAtttribute("Accessor", "Returns Value of getAccountNumber")]
            public int getAccountNumber()
            {
                return Accountnumber;
            }

            [SoftwareAtttribute("Accessor", "Returns Value of accountholderName")]
            public string accountholderName()
            {
                return AccountholderName;
            }

            [SoftwareAtttribute("Accessor", "Returns Value of Balance")]
            public double balance()
            {
                return Balance;
            }
            [SoftwareAtttribute("Accessor", "Returns Value of Pincode")]
            public double pinCode()
            {
                return pincode;
            }

        }


            class Test
            {   
                static void Main(string[] args)
                {

                    SoftwareAtttribute.SoftwareAttributeDisplay(typeof(HDFCAccount));
                    SoftwareAtttribute.SoftwareAttributeDisplay(typeof(ICICIAccount));

                    Console.ReadKey();
                }
            }
        }
    }

