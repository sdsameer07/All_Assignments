﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmpManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace EmpManagementSystem.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeDbContext context;
        public EmployeeController(EmployeeDbContext db)
        {
            context = db;
        }
        public async Task<IActionResult> Index()
        {
            var emp = await context.employeetable.ToListAsync();
            return View(emp);
        }
        public IActionResult Create() 
        { 
            return View(); 
        }
        [HttpPost] 
        public IActionResult Create(Employee employee)
        {
            context.employeetable.Add(employee);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public async Task<IActionResult> Edit(int? EmpId)
        {
            var emp = await context.employeetable.FindAsync(EmpId);
            return View(emp);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int EmpId, [Bind("EmpName,EmpLocation,EmpSalary")] Employee Employeedata)
        {
            Employee p1 = await context.employeetable.FindAsync(EmpId);
            // p1 = new Employee();            
            //if (ModelState.IsValid)
            //{
                try
                {
                    p1.EmpName = Employeedata.EmpName;
                    p1.EmpLocation = Employeedata.EmpLocation;
                    p1.EmpSalary = Employeedata.EmpSalary;                    
                    context.employeetable.Update(p1);
                    await context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
           // }
            return View(nameof(Index));
        } 

        public IActionResult Delete(int EmpId)
        {
            var emp = context.employeetable.SingleOrDefault(e => e.EmpId == EmpId);
            context.employeetable.Remove(emp);
            context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
