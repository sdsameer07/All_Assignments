﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    class Class1
    {
            static void Main(string[] args)

        {

            Program p = new Program();

            p.show(2, 3, 8);

            int[] a = { 2, 90, 78, 45 };

            Console.WriteLine("example of array");

            Console.WriteLine("elements added are");

            p.show(a);

            Console.ReadLine();

        }

        public void show(params int[] b)

        {

            foreach (int i in b)

            {

                Console.WriteLine("ARRAY IS HAVING:{0}", i);

            }

        }
    }
}
