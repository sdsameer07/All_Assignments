﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeWebApiService.Models;

namespace EmployeeWebApiService.Repository
{
    public interface IAccountRepository
    {
        Task<Employee> VerifyLogin(string EmployeeEmail, string Employeepassword);

    }
}
