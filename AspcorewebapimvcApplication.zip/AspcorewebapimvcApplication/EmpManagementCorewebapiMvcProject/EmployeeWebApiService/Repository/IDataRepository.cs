﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeWebApiService.Models;

namespace EmployeeWebApiService.Repository
{
    public interface IDataRepository
    {
        Task<List<Employee>> GetEmployees();

        Task<Employee> GetEmployee(int? Id);

        Task<int> AddEmployee(Employee employee);

        Task<int> DeleteEmployee(int? Id);

        Task UpdateEmployee(Employee employee);
    }
}
