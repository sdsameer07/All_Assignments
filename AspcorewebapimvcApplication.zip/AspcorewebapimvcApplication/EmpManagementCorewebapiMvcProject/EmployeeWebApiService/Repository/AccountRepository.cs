﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeWebApiService.Models;
using EmployeeWebApiService.Repository;

namespace EmployeeWebApiService.Repository
{
    public class AccountRepository : IAccountRepository
    {
        private readonly EmployeeDbContext _DBContext;

        // Constructor Dependency Injection
        public AccountRepository(EmployeeDbContext DBContext)
        {
            _DBContext = DBContext;
        }
        public Employee VerifyLogin(string Employeeemail, string Employeepassword)
        {
            Employee employee = null;
            try
            {
                var employeeFound = _DBContext.employeeTable.Where(u => u.EmployeeEmail == Employeeemail && u.EmployeePassword == Employeepassword)
                                     .SingleOrDefault();

                if (employeeFound != null)
                {
                    employee = employeeFound;
                }
                else
                {
                    employee = null;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return employee;
        }

        

        Task<Employee> IAccountRepository.VerifyLogin(string EmployeeEmail, string Employeepassword)
        {
            throw new NotImplementedException();
        }
    }
}
