﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeWebApiService.Repository;
using EmployeeWebApiService.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeWebApiService.Repository
{
    public class EmployeeRepository : IDataRepository
    {
         EmployeeDbContext context;
        public EmployeeRepository(EmployeeDbContext _context)
        {
            context = _context;
        }     
        public async Task<List<Employee>> GetEmployees()
        {
            if (context != null)
            {
                return await(from u in context.employeeTable


                             select new Employee
                             {
                                 Id = u.Id,
                                 EmployeeName = u.EmployeeName,
                                 EmployeePassword = u.EmployeePassword,
                                 EmployeeEmail = u.EmployeeEmail,
                                 EmployeeLocation = u.EmployeeLocation,
                             }).ToListAsync();
            }

            return null;
        }

        public async Task<Employee> GetEmployee(int? Id)
        {
            if (context != null)
            {
                return await(from u in context.employeeTable

                             where u.Id == Id
                             select new Employee
                             {
                                 Id = u.Id,
                                 EmployeeName = u.EmployeeName,
                                 EmployeePassword = u.EmployeePassword,
                                 EmployeeEmail = u.EmployeeEmail,
                                 EmployeeLocation = u.EmployeeLocation,

                             }).FirstOrDefaultAsync();
            }

            return null;
        }

        public async Task<int> AddEmployee(Employee employee)
        {
            if (context != null)
            {
                await context.employeeTable.AddAsync(employee);
                await context.SaveChangesAsync();

                return employee.Id;
            }

            return 0;
        }

        public async Task<int> DeleteEmployee(int? Id)
        {
            int result = 0;

            if (context != null)
            {
                //Find the post for specific post id
                var user = await context.employeeTable.FirstOrDefaultAsync(x => x.Id == Id);

                if (user != null)
                {
                    //Delete that post
                    context.employeeTable.Remove(user);

                    //Commit the transaction
                    result = await context.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

        public async Task UpdateEmployee(Employee employee)
        {
            if (context != null)
            {
                //Delete that post
                context.employeeTable.Update(employee);

                //Commit the transaction
                await context.SaveChangesAsync();
            }
        }
    }
}
