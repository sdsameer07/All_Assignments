﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeWebApiService.Repository;
using EmployeeWebApiService.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeWebApiService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IDataRepository dataRepository;
        public EmployeeController(IDataRepository _dataRepository)
        {
            dataRepository = _dataRepository;
        }



        [HttpGet]
        [Route("GetEmployees")]
        public async Task<IActionResult> GetEmployees()
        {
            try
            {
                var employees = await dataRepository.GetEmployees();
                if (employees == null)
                {
                    return NotFound();
                }

                return Ok(employees);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpGet]
        [Route("GetEmployeebyId")]
        public async Task<IActionResult> GetEmployeebyId(int? id)
        {
            if (id == null)
            {
                return BadRequest();
            }

            try
            {
                var employee = await dataRepository.GetEmployee(id);
                if (employee == null)
                {
                    return NotFound();
                }

                return Ok(employee);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [Route("AddEmployee")]
        public async Task<IActionResult> AddEmployee([FromBody] Employee model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var postId = await dataRepository.AddEmployee(model);
                    if (postId > 0)
                    {
                        return Ok(model);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpDelete]
        [Route("DeleteEmployee")]
        public async Task<IActionResult> DeleteEmployee(int Id)
        {

            Employee employee = await dataRepository.GetEmployee(Id);
            try
            {
                var result = await dataRepository.DeleteEmployee(employee.Id);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok("Record is deleted ..!");
            }
            catch (Exception)
            {

                return BadRequest();
            }
        }


        [HttpPut]
        [Route("UpdateEmployee")]
        public async Task<IActionResult> UpdateEmployee(int id, [FromBody] Employee model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await dataRepository.UpdateEmployee(model);

                    return Ok(model);
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}
