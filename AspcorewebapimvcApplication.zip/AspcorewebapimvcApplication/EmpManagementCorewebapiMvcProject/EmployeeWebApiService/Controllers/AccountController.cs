﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.Http;
using EmployeeWebApiService.Models;
using EmployeeWebApiService.Repository;

namespace EmployeeWebApiService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private IAccountRepository _accountRepository;

        // Loose Coupling
        // NInject or Unity Dependency Injection Container
        //public UserController(IDataRepository<User> dataRepository)
        //{
        //    this._dataRepository = dataRepository;
        //}

        // Tight Coupling
       

        //POST: api/accounts/login
       /* [HttpPost]
        [Route("login")]
        public async Task<IActionResult> VerifyLogin(Login login)
        {
            Employee employee = null;
            try
            {
               employee =  await _accountRepository.VerifyLogin(login.EmployeeEmail, login.EmployeePassword);
                if (employee == null)
                    return NotFound();
            }
            
            catch (Exception ex)
            {
                throw ex;
            }
            return Ok(employee);
        }
       */
    }
}
