﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EmployeeWebApiService.Models
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [Required]
        [Display(Name = "EmployeeName")]
        public string EmployeeName { get; set; }
        [Required]
        [Display(Name = "EmployeePassword")]
        public string EmployeePassword { get; set; }
        [Required]
        [Display(Name = "EmployeeEmail")] 
        public string EmployeeEmail { get; set; }
        [Required]
        [Display(Name = "EmployeeLocation")]
        public string EmployeeLocation { get; set; }

    }
}

