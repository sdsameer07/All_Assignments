﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using EmployeeMvc.Models;


namespace EmployeeMvc.Controllers
{
    public class EmployeeController : Controller
    {
        HttpClientHandler clientHandler = new HttpClientHandler();
        // GET: EmployeeController
        public async Task<ActionResult> Index()
        {
            List<EmployeeViewModel> employees = new List<EmployeeViewModel>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://localhost:44358/api/Employee/GetEmployees"))
                {
                    string apiResponse
                        = await response.Content.ReadAsStringAsync();
                    employees = JsonConvert.DeserializeObject<List<EmployeeViewModel>>(apiResponse);
                }
            }
            return View(employees);
        }

        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(EmployeeViewModel employee)
        {
            if (ModelState.IsValid)
            {
                EmployeeViewModel newEmployee = new EmployeeViewModel();
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("https://localhost:44358/api/Employee/AddEmployee", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        newEmployee = JsonConvert.DeserializeObject<EmployeeViewModel>(apiResponse);
                    }

                }
                return RedirectToAction("Index");

            }

            return View(employee);

        }
        public async Task<ActionResult> Details(int id)
        {
            EmployeeViewModel employee = new EmployeeViewModel();
            using (var httpClient = new HttpClient())

            {
                using (var response = await httpClient.GetAsync("https://localhost:44358/api/Employee/GetEmployeebyId?id=" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    employee = JsonConvert.DeserializeObject<EmployeeViewModel>(apiResponse);
                }
            }
            return View(employee);
        }

        public async Task<ActionResult> Edit(int id)
        {
            EmployeeViewModel employee = new EmployeeViewModel();
            using (var httpClient = new HttpClient())
            {

                using (var response
                     = await httpClient.GetAsync("https://localhost:44358/api/Employee/GetEmployeebyId?id=" + id))
                {
                    string apiResponse  = await response.Content.ReadAsStringAsync();
                    employee  = JsonConvert.DeserializeObject<EmployeeViewModel>(apiResponse);
                }
            }
            return View(employee);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(EmployeeViewModel employee)
        {
            EmployeeViewModel updatedEmployee = new EmployeeViewModel();

            using (var httpClient = new HttpClient())
            {
                var content = new MultipartFormDataContent();
                content.Add(new StringContent(employee.Id.ToString()), "Id");
                content.Add(new StringContent(employee.EmployeeName), "FirstName");
                content.Add(new StringContent(employee.EmployeePassword), "LastName");
                content.Add(new StringContent(employee.EmployeeEmail), "Email");
                content.Add(new StringContent(employee.EmployeeLocation), "Employee Location");
                
                StringContent Content = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");

                using (var response = await httpClient.PutAsync("https://localhost:44358/api/Employee/UpdateEmployee", Content))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    updatedEmployee = JsonConvert.DeserializeObject<EmployeeViewModel>(apiResponse);
                }
            }
            return RedirectToAction("Index");
        }

        //// GET: EmployeeController/Delete/5
        [HttpGet]
        public async Task<ActionResult> Delete(int id)
        {
            EmployeeViewModel employee = new EmployeeViewModel();
            using (var httpClient = new HttpClient())            {

                using (var response
                     = await httpClient.GetAsync("https://localhost:44358/api/Employee/GetEmployeebyId?id=" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    employee = JsonConvert.DeserializeObject<EmployeeViewModel>(apiResponse);
                }
            }
            return View(employee);
        }

        ////// POST: EmployeeController/Delete/5

        [HttpPost]
        public async Task<IActionResult> Delete(EmployeeViewModel employee)
        {

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.DeleteAsync("https://localhost:44358/api/Employee/DeleteEmployee?Id=" + employee.Id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                }

            }

            return RedirectToAction("Index");
        }
    }
}
