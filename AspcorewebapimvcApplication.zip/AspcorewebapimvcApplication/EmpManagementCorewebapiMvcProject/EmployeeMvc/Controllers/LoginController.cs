﻿using Microsoft.AspNetCore.Mvc;

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

using EmployeeMvc.Models;

namespace EmployeeMvc.Controllers
{
    public class LoginController : Controller
    {
 // GET: Login
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }
       /* [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login([Bind(Include = "Email, Password")]
                EmployeeLoginModel login)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    EmployeeLoginModel newUser = new EmployeeLoginModel();
                    var service = new ServiceRepository();
                    {
                        using (var response = service.PostResponse("accounts/login", login))
                        {
                            string apiResponse = await response.Content.ReadAsStringAsync();
                            newUser = JsonConvert.DeserializeObject<EmployeeLoginModel>(apiResponse);
                        }
                    }
                    if (newUser != null)
                    {
                        FormsAuthentication.SetAuthCookie(login.EmployeeEmail, false);
                        return RedirectToAction("Index", "User");
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "The Email or Password provided is incorrect";
                    }
                }
            }
            catch
            {

            }
            return View();

        }
       */
    }
}
