﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace EmployeeMvc.Models
{
    public class EmployeeViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Employee Name is required")]
        [StringLength(50, MinimumLength = 3)]
        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }

        [Required(ErrorMessage = "Employee Password is required")]
        [StringLength(50, MinimumLength = 0)]
        [Display(Name = "Employee Password")]
        public string EmployeePassword { get; set; }

        [Display(Name = "Employee Email")]
        [Required(ErrorMessage = "Employee Email is required")]
        [StringLength(60)]
        [DataType(DataType.EmailAddress, ErrorMessage = "Invalid Email Address")]
        public string EmployeeEmail { get; set; }

        [Display(Name = "Employee Location ")]
        [Required(ErrorMessage = "Employee Location is required")]
        [StringLength(60)]
        public string EmployeeLocation { get; set; }


    }
}
